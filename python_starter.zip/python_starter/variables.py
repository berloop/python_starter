x = 1
y =.5
name='John Connor' 
isActive = True
y = (x/y) * x
print(name,x,isActive,y)

#casting..
x = str(x)
y = int(y)
print (type(y),type(x),y,x)